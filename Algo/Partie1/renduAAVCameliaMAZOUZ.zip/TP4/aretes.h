#ifndef H_ARETES
#define H_ARETES


typedef struct cellule{
    int u,v,poid;
}aretes;

void afficheArete(aretes * liste,int ordre);

#endif